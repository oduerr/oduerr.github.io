
proposed_mapping = function( mapping0 ){

  # select 2 letters to switch
  proposal = sample(1:26, 2) 
  
  # use global assignment
  prop.mapping = mapping0
  prop.mapping[ proposal[1] ] = mapping0[ proposal[2] ]
  prop.mapping[ proposal[2] ] = mapping0[ proposal[1] ]
  
  return( prop.mapping )
  
}
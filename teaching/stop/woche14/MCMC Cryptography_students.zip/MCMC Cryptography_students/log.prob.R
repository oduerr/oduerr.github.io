log.prob = function(mapping, decoded) {
  
  logprob = 0
  lastletter = ""
  
  for ( i in 1:nchar(decoded) ) {
    
    symbol_current = substring(decoded, i, i)
    
    if (symbol_current %in% LETTERS) {
      logprob = logprob + log(trans.prob.mat[ rownames(trans.prob.mat) == lastletter,
                                              colnames(trans.prob.mat) == symbol_current ])
      lastletter = symbol_current
      
    } else {
      
      if (lastletter != "") {
        logprob = logprob + log( trans.prob.mat[rownames(trans.prob.mat) == lastletter, 27] )
        lastletter = ""
        
      }
    }
  }
  
  if (lastletter != "") {
    logprob = logprob + log( trans.prob.mat[rownames(trans.prob.mat) == lastletter, 27])
    lastletter = ""
  }
  return(logprob)
}


decode = function(mapping, coded) {
  
  coded = toupper(coded)
  decoded = coded
  
  for ( i in 1:nchar(coded) ) {
    
    if ( substring(coded, i, i ) %in% LETTERS ) {
      
      substring(decoded, i, i) = LETTERS[mapping == substring(coded, i, i)]
      
    }
  }
  return(decoded)
}